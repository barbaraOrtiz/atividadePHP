<?php 
    include "usuarios.php";
    
    $myuser= new usuarios();
    $myuser->setNome($_POST['nome']);
    $myuser->setEmail($_POST['email']);
    $myuser->setId($_POST['id']);
    $myuser->update($_POST['id']);
    header("Location: indexAtividade.php" );
?>
    