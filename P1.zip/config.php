<?php
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'id12544696_banco1');
	define('DB_USER', 'id12544696_app');
	define('DB_PASS', '1234Barbara!');
?>
