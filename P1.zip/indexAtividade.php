<?php
    ob_start();
	include "usuarios.php";
	require_once 'Crud.php';
	
	header('Content-Type: text/html; charset=utf-8');
	ob_flush();
?>

<!DOCTYPE html>
<html>
	
	<head>
		<meta http-equiv="content-type" content="text/html;charset=utf-8" /> 
		<title> Cadastro Usuário </title>
	</head>
	
	<body>
		<b>
			<?php
			ob_start();
			    function exibicao()
            	{
            	    echo"<form method=POST action=".$_SERVER['PHP_SELF'].">";
            	    echo"<input type=hidden name=funcao value=inserir>";
            	    echo"<H2>Nome: <input type=text name=nomeUsuario></H2>";
            		echo"<br/>";
            		echo"<H2>Email: <input type=text name=emailUsuario></H2>";
            		echo"<br/>";
            		echo"<H2>Senha: <input type=password name=senhaUsuario></H2>";
            		echo"<br/>";
            		echo"<input type=submit value=Enviar>";
            		echo"</form>";
            	}
            	
				$myuser = new usuarios();
				
				$funcao = (isset($_POST['funcao']) ) ? $_POST['funcao'] : null;
	            
				switch ($funcao)
				{
				    case "logoff":
				        {
				            header("Location: login.php");
				            break;
				        }
				    case "alterar":
				        {
				            echo"<form method=POST action=alterar.php>";
				            echo"<input type=hidden name=funcao value=alterar>";
				            echo"<H2>Nome: <input type=text name=nome value=".$_POST['nomeUsuario']."></H2>";
				            echo"<br/>";
				            echo"<H2>Email: <input type=text name=email value=".$_POST['emailUsuario']."></H2>";
				            echo"<br/>";
				            echo"<input type=hidden name=id value=".$_POST['idUsuario'].">";
				            $myuser->setId($_POST['idUsuario']);
				            echo"<input type=submit value=Enviar>";
				            echo"<input type=hidden name=funcao value=inserir>";
				            echo"</form>";
				            break;
				        }
				        
				    case "excluir":
				        {
				            $myuser->setId($_POST['idUsuario']);
				            $myuser->delete($_POST['idUsuario']);
				    
				            exibicao();
				            break;
				        }
				    
				    case "inserir":
				        {
				            if ($_POST['senhaUsuario'] == 123456)
				            {
				                echo "Senha não pode ser igual a padrão do sistema!";
				            }
				            else
				            {
				                
    					        $myuser->setNome($_POST['nomeUsuario']);
    					        $myuser->setEmail($_POST['emailUsuario']);
    					        $myuser->setSenha(md5($_POST['senhaUsuario']));
    					        $myuser->insert();
    					        
				            }
					        exibicao();
					        break;
				        }
				        
				    case "resetSenha":
				        {
				            $myuser->setSenha(md5(123456));
				            $myuser->updateSenha(($_POST['idUsuario']));
				            
				            exibicao();
				            break;
				        }
				        
				    default:
				        {
				            exibicao();
				            break;
				        }    
				}
			ob_flush();	
			?>
			</b>
			<br/>
			<table border = 1>
				<tr>
					<th width="20%">Nome</th>
					<th width="20%">Email</th>
					<th width="20%">Alterar</th>
					<th width="20%">Excluir</th>
					<th width="20%">Recuperação de Senha</th>
				</tr>
				
				<?php foreach($myuser->findAll() as $key=>$value):?>
				<tr>
					<td><?php echo "$value->nome";?></td>
					<td><?php echo "$value->email";?></td>	
					<td>
					    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					        <input type="hidden" name="funcao" value="alterar";>
					        <input type="hidden" name="nomeUsuario" value=<?php echo"$value->nome";?>>
					        <input type="hidden" name="emailUsuario" value=<?php echo"$value->email";?>>
					        <input type="hidden" name="senhaUsuario" value=<?php echo"$value->senha";?>>
					        <input type="hidden" name="idUsuario" value=<?php echo"$value->id";?>>
					        <input type="submit" value="Alterar">
					   </form>
				    </td>
				    <td>
					    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					        <input type="hidden" name="funcao" value="excluir";>
					        <input type="hidden" name="idUsuario" value=<?php echo"$value->id";?>>
					        <input type="submit" value="Excluir">
					    </form>
					</td>
					<td>
					    <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
					        <input type="hidden" name="funcao" value="resetSenha";>
					        <input type="hidden" name="idUsuario" value=<?php echo"$value->id";?>>
					        <input type="submit" value="Resetar Senha">
					   </form>
				    </td>
				</tr>
				<?php endforeach;?>
			</table>
			</br>
			<form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
			    <input type="hidden" name="funcao" value="logoff";>
			    <input type="submit" value="Logoff">
			</form> 
	</body>
</html>