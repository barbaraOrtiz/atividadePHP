<?php 
    ob_start();
	include "usuarios.php";
	require_once 'Crud.php';
	ob_flush();
?>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <LINK rel="stylesheet" href="design.css">
  <style> 
  input[type=submit] 
  {
	  font-family: "Roboto", sans-serif;
	  text-transform: uppercase;
	  outline: 0;
	  background: #DF013A;
	  width: 100%;
	  border: 0;
	  padding: 15px;
	  color: #FFFFFF;
	  font-size: 14px;
	  -webkit-transition: all 0.3 ease;
	  transition: all 0.3 ease;
	  cursor: pointer;
  }
  </style>
  
</head>
<body>
  <div class="login-page">
  <div class="form">
    
	<form method='POST' "<?php echo $_SERVER['PHP_SELF'];?>">
    <form class="login-form">
      <input type="text" placeholder="E-mail" name="email"/>
      <input type="password" placeholder="Senha" name="senha"/>
	  
      <input type="submit" value="Entrar"/>
	  <?php
	    ob_start();
		$myuser = new usuarios();
		
		if (isset($_POST['email']) and isset($_POST['senha']))
		{
		    $myuser->setEmail($_POST['email']);
			$myuser->setSenha(md5($_POST['senha']));
			
			$retorno = $myuser->autenticacao();
			
			session_start();
			$_SESSION['idCliente'] = $retorno;
			
			if($myuser->getSenha() == (md5(123456)) && $retorno > 0)
			{
			    header("Location: redefinicaoSenha.php");
			}
			else if ($myuser->getSenha() != (md5(123456)) && $retorno > 0)
			{
			    header("Location: indexAtividade.php");
			}
			else
			{
			    echo "Usuario/Senha incorretos";
			}
		}
		else
		{
		    echo "Campos são obrigatórios!";
		}
		ob_flush();
	  ?>
    </form>
  </div>
</div>
</body>
</html>