<?php 
    ob_start();
	include "usuarios.php";
	require_once 'Crud.php';
	ob_flush();
?>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <LINK rel="stylesheet" href="design.css">
  <style> 
  input[type=submit] 
  {
	  font-family: "Roboto", sans-serif;
	  text-transform: uppercase;
	  outline: 0;
	  background: #DF013A;
	  width: 100%;
	  border: 0;
	  padding: 15px;
	  color: #FFFFFF;
	  font-size: 14px;
	  -webkit-transition: all 0.3 ease;
	  transition: all 0.3 ease;
	  cursor: pointer;
  }
  </style>
  
</head>
<body>
  <div class="login-page">
  <div class="form">
    
	<form method='POST' "<?php echo $_SERVER['PHP_SELF'];?>">
    <form class="login-form">
      <input type="password" placeholder="Nova Senha" name="novasenha"/>
      <input type="password" placeholder="Confirmar Nova Senha" name="confirmarsenha"/>
	  
      <input type="submit" value="Redefinir"/>
	  <?php
	    ob_start();
		$myuser = new usuarios();
		
		if (empty($_POST['novasenha']) and empty($_POST['confirmarsenha']))
		{
		    echo "Campos são obrigatórios!";
		}
		else
		{
		    $novaSenha = (isset($_POST['novasenha']) ) ? $_POST['novasenha'] : null;
		    $confirmacao = (isset($_POST['confirmarsenha']) ) ? $_POST['confirmarsenha'] : null;
		    
		    if ($novaSenha == $confirmacao && $novaSenha != 123456)
		    {
		       session_start();
		       $id =  $_SESSION['idCliente'];
		       print_r ($id);
			   $myuser->setSenha(md5($_POST['confirmarsenha']));
			   $myuser->updateSenha($id);
			   header("Location: login.php");
		    }
		    else if ($novaSenha == 123456)
		    {
		        echo "Senha digitada não pode ser igual a senha padrão do sistema!";
		    }
		    else
		    {
		        echo "As senhas não coincidem!";
		    }
		}
		ob_flush();
	  ?>
    </form>
  </div>
</div>
</body>
</html>